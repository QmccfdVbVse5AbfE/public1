package edu.brown.cs.cs32friends.plant;

//Tests to see if the correct url is returned. To be combined with the plant class.
public class PlantImage {
    String url;

    public void setUrl(String url) {
        this.url = url;
    }
    
    public String getUrl() {
        return this.url;
    }
}
