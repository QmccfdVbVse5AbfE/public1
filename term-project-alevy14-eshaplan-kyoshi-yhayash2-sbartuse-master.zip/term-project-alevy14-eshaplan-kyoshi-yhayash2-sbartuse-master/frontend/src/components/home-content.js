import React from "react";
import './home.css'
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faLink } from "@fortawesome/free-solid-svg-icons";

const HomeContent = () => (

<html className='home' >
</html>

);

export default HomeContent;
